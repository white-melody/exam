package exam;

import java.util.Arrays;
import java.util.Scanner;

public class s3 {

	public static void main(String[] args) {
		Scanner scanner1 = new Scanner(System.in);
		int N = scanner1.nextInt();
		int[] a = new int[N];
		Scanner scanner2 = new Scanner(System.in);
		
		for(int i =0; i < N; i++) {
		int b = scanner2.nextInt();
		a[i] = b;
		}
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
	}

}
