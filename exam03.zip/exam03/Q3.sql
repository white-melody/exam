-- 부서번호(DNO)가 10또는 30에 속하고 
-- 부서번호별,부서명별 최고급여가 3000이상인 사원의 
-- 부서번호,부서명,최고급여를 화면에 표시하세요

SELECT E.DNO, D.DNAME, MAX(E.SALARY) FROM EMPLOYEE E,DEPARTMENT D
WHERE E.DNO = D.DNO AND E.DNO IN (10,30) AND SALARY >=3000
GROUP BY E.DNO, D.DNAME; 
