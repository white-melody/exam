-- 사원명이 SCOTT인 사람의 정보를 모두 화면에 표시하세요

SELECT * FROM EMPLOYEE
WHERE ENAME = 'SCOTT';